from kivy.app import App
from kivy.core.text import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.screenmanager import Screen, ScreenManager


# ------Стартовое окно------
class MainWindow(Screen):
    def __init__(self):
        super().__init__()
        main_layout = FloatLayout()
        self.name = "Main"
        self.add_widget(main_layout)
    def button_start(self):
        self.manager.current = "two"
        return 0
# ------Добро пожаловать)------    
class Dobro_Pogalovaty(Screen):
    def __init__(self):
        super().__init__()
        main_layout = FloatLayout()
        self.add_widget(main_layout)
        self.name = "two"
    def dalee(self):
        self.manager.current = "menu"
        return 0

# ------Меню------
class Menu(Screen):
       def __init__(self):
           super().__init__()
           main_layout = FloatLayout()
           self.add_widget(main_layout)
           self.name = "menu"
    
# ------Ядро------
sm = ScreenManager()
class MainApp(App):

    def build(self):
        sm.add_widget(MainWindow())
        sm.add_widget(Menu())
        sm.add_widget(Dobro_Pogalovaty())
        return sm

# ------Запуск------
if __name__ == '__main__':
    app = MainApp()
    app.run()
