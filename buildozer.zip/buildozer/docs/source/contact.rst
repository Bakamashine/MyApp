.. _contact:

Contact Us
==========

If you are looking to contact the Kivy Team (who are responsible for managing the
Buildozer project), including looking for support, please see our
`latest contact details <https://github.com/kivy/buildozer/blob/master/CONTACT.md>`_.