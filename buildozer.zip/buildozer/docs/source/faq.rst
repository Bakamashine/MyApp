FAQ
===

Buildozer has an `online FAQ <https://github.com/kivy/buildozer/blob/master/FAQ.md>`_. It contains the answers to
questions that repeatedly come up.
